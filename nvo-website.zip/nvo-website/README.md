# New Vision Organization, Inc. website

A static website for New Vision Organization, Inc. (NVO). It needs no build step or server code.

## Files

- `index.html`: the whole site. Each page is a section shown through the link after `#`, for example `#about` or `#volunteer`.
- `img/`: photos and the logo mark.

## Publish with GitHub Pages

1. Create a new repository on GitHub and upload `index.html`, `README.md` and the `img` folder, keeping the folder structure.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select the `main` branch and the `/ (root)` folder, then save.
4. After a minute or two the site appears at `https://<your-username>.github.io/<repository-name>/`.

To use your own domain, add it under **Settings → Pages → Custom domain**.

## Editing content

All text lives in `index.html`. Search for the words you want to change and edit them in place.
The partner directory and podcast episode lists are near the bottom of the file, in the `ORGS`, `RECENT` and `ARCHIVE` lists inside the `<script>` block.

## Notes

- The volunteer page points people to email and VolunteerMatch. To add a contact form, connect a form service such as Formspree or Netlify Forms.
- Podcast play buttons open the current Wix podcast page. Replace the `LISTEN` link in the script, or give each episode its own link, once the audio is hosted elsewhere.
- Fonts load from Google Fonts.
